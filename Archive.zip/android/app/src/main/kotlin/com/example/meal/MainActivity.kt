package com.example.meal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
